/**
 * Dasboard Routes
 */
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import  Access  from '../../constants/AccessConfig'; 
// async components
import {
   AsyncSorterDetailsComponent,
   AsyncChuteStatusComponent,
   AsyncManageEquipmentDashboard,
   AsyncInductStatusComponent,
   AsyncGtpDashboard,
   AsyncGtpZnlStnDtls
   
} from 'Components/AsyncComponent/AsyncComponent';

const Dashboard = ({ match }) => (
   <div className="dashboard-wrapper">
      <Switch>
         <Redirect exact from={`${match.url}/`} to={`${match.url}/manageEquipment`} />
		 <Route path={`${match.url}/gtp/:operationStatus/znlstnDtls`} component={AsyncGtpZnlStnDtls} />
		 <Route path={`${match.url}/gtp`} component={AsyncGtpDashboard} />
         <Route exact path={`${match.url}/sorterDetails/:sorterID`} component={AsyncSorterDetailsComponent} />
		 { JSON.parse(localStorage.getItem("assignedPermissions")).indexOf(Access.ManageEquipment) !== -1 && 
        	 <Route path={`${match.url}/manageEquipment`} component={AsyncManageEquipmentDashboard} />
         } 
         <Route path={`${match.url}/:sorterID/chuteDetails`} component={AsyncChuteStatusComponent} />
         <Route path={`${match.url}/:sorterID/inductDetails`} component={AsyncInductStatusComponent} />
      </Switch>
   </div>
);

export default Dashboard;
