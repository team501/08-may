/**
 * Data Table
 */
import React from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';
import {baseURL} from '../../../services/Config.js';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';

import TableConfig from  "JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/inductsTableConfig/inductTableJson.json"

import {graphQlURLPrd} from '../../../services/Config.js';
import Spinner from 'Util/Spinner';

class inductStatus extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = {  data: [],
					isLoading:true
				};
	}
		
      
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
	}

	//Fetch Sorter ID from URL params
	 sorterID  = this.props.match.params.sorterID;
	
	onReload = () => {
		let query = TableConfig.container.leftSegment.components[0].options.query;

		let startTime = 201903231431;//dateFormat(new Date(), "yyyymmddHHMM");
		let stationGoal = TableConfig.container.leftSegment.components[0].options.stationGoal;
		let sorterId = this.sorterID;
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, sorterId, stationGoal }
			})
		})
		.then(r => r.json())
		.then(data => { 
			
		    this.setState({ data: data.data.getInductionStationStatusDetails.details,
				   			sorterId: data.data.getInductionStationStatusDetails.sorterId,
						    isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ data: [],
				   			sorterId: '',
						    isLoading:false
						 }); 
		});
	}

	
	render() {
		
		//from json
		let segmentsForBgClr = TableConfig.container.leftSegment.components[0].options.segments;
		let recordsPerPage = TableConfig.container.leftSegment.components[0].options.recordsPerPage;
		
	    const rows = this.state.data; 
		
		const { match } = this.props;

		const { isColorBlind } = this.props;
      

		const blindColors = [ "#87871f", "#f8e71c", "#828275", "#5f5fb3" ];

		const tableColors = isColorBlind ? blindColors : TableConfig.container.leftSegment.components[0].options.colors;
						localStorage.setItem("colors", isColorBlind);

		

		// Function to set color for cells
		const setColor = (segments, colors, inductsValue) => {
			if(segments != null && segments != undefined && Array.isArray(segments)){
				for (let i = 0; i < segments.length; i++) {
					const startRange = segments[i];
					const endRange = segments[i+1];
					if( i === segments.length - 1){
						if(inductsValue > startRange)
						return colors[i % colors.length];
					} else {
						if(inductsValue != 0 && (inductsValue > startRange && inductsValue <= endRange))
						return colors[i % colors.length];
					}
				}
			}
			
			return "#c3c3c3";
		};

		//Bootstrap datatable custom cell style
		const { SearchBar } = Search;
		const headerSortingStyle = { backgroundColor: '#D5D8DC' };
		const headerStyle = { fontWeight: 600, border:'none', backgroundColor: '#ffffff'};

		//Set Caret icon for sorting directions
		const sortCaret = (order, column) => {
			if (!order) return (<span class="order">&nbsp;&nbsp;<span class="dropdown"><span class="icon-arrow-up"></span></span><span class="dropup"><span class="icon-arrow-down"></span></span></span>);
			else if (order === 'asc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-up"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
			else if (order === 'desc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-down"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
			return null;
		};

		const columns = [
			{
				dataField: 'stationId',
				text: '',
				sort: true,
				style: (cell, row, rowIndex, colIndex) => {
					const backgroundColor = setColor(segmentsForBgClr, tableColors, row.inductsPerHour);
					const color = '#ffffff';
					return { backgroundColor, color };
				},
				classes: 'table-key-row',
				headerStyle 
			},
			{
				dataField: 'runTime',
				text: <IntlMessages id="inductStatusTable.Runtime" />,
				align: 'center',
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader'
			},
			{
				dataField: 'totalInducts',
				text: <IntlMessages id="inductStatusTable.Total Inducts" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				formatter: (cell, row) => {
					return (
						<NumberClass  number={cell} />
					);
				}
			},
			{
				dataField: 'inductsPerHour',
				text: <IntlMessages id="inductStatusTable.Induct/hour" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				formatter: (cell, row) => {
					return (
						<NumberClass  number={cell} />
					);
				}
			},
			{
				dataField: 'productivity',
				text: <IntlMessages id="inductStatusTable.Productivity" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				style: (cell, row, rowIndex, colIndex) => {
					const color = setColor(segmentsForBgClr, tableColors, row.inductsPerHour);
					return { color };
				},
				formatter: (cell, row) => {
					return (
						<span> { cell }%</span>
					);
				}
			},
			{
				dataField: 'peakRate',
				text: <IntlMessages id="inductStatusTable.Peak Rate" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				formatter: (cell, row) => {
					return (
						<NumberClass  number={cell} />
					);
				}
			},
			{
				dataField: 'minRate',
				text: <IntlMessages id="inductStatusTable.Min Rate" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				formatter: (cell, row) => {
					return (
						<NumberClass  number={cell} />
					);
				}
			},
			{
				dataField: 'avgRate',
				text: <IntlMessages id="inductStatusTable.Average Rate" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader',
				formatter: (cell, row) => {
					return (
						<NumberClass  number={cell} />
					);
				}
			},
			{
				dataField: 'currentUser',
				text: <IntlMessages id="inductStatusTable.Current user" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader'
			},
			{
				dataField: 'lastScan',
				text: <IntlMessages id="inductStatusTable.Last Scan" />,
				sort: true,
				sortCaret,
				headerSortingStyle,
				classes: 'table-key-row',
				headerClasses: 'dataTableHeader'
			}
		];

		//Custom search results information
		const customTotal = (from, to, size) => (
			<span className="react-bootstrap-table-pagination-total">
				<IntlMessages id="Table.Pagination.Showing" /> { from } <IntlMessages id="Table.Pagination.to" /> { to } <IntlMessages id="Table.Pagination.of" /> { size } <IntlMessages id="Table.Pagination.Results" />
			</span>
		);
		
		//Defininf options for pagination
		const options = {
			paginationSize: 4,
			pageStartIndex: 1,
			alwaysShowAllBtns: true, // Always show next and previous button
			withFirstAndLast: true, // Hide the going to First and Last page button
			hideSizePerPage: true, // Hide the sizePerPage dropdown always
			hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
			showTotal: true,
			paginationTotalRenderer: customTotal,
			sizePerPageList: [
				{
					text: recordsPerPage, value: recordsPerPage //number of results per page
				}
			] // A numeric array is also available. the purpose of above example is custom the text
		};
		
		//Custom Reload button for data rerendering
		const ReloadButton = () => {
			return (
			  <div>
				<button className="btn pull-right" onClick={() => {this.setState({isLoading: true}); this.onReload()}}>
					<span aria-hidden="true" class="icon-refresh"></span>
				</button>
			  </div>
			);
		  };

		  if(this.state.isLoading){
			  return (  <div className="data-table-wrapper">
						  	<PageTitleBar 
						  	url={`/app/dashboard/sorterDetails/${this.sorterID}`} 
						  	title={<IntlMessages id="inductStatusTable.title" />}
						  	subTitle={" " +`${this.sorterID}`} 
						  	match={match} 
						  	/>

						  <RctCard>
						  <RctCardContent>
									<Spinner />
						  </RctCardContent>
						  </RctCard ></div>);
		  } else {
			return (
				<div className="data-table-wrapper">
					<PageTitleBar 
						url={`/app/dashboard/sorterDetails/${this.sorterID}`} 
						title={<IntlMessages id="inductStatusTable.title" />}
						subTitle={" "+`${this.sorterID}`} 
						match={match} 
					/>
					<RctCard>
			        <RctCardContent>
						<ToolkitProvider
							keyField={Math.floor((Math.random() * 10000000) + 1)} //Generate unique rendom number between 0 to 10000000 for row key
							data={ this.state.data } //Input data
							columns={ columns }
							search 
							>
							{
								props => (
								<div>
									<ReloadButton { ...props.searchProps } />
									<SearchBar
									{ ...props.searchProps }
									className="custome-search-field"
									style={ { color: 'black' } }
									delay={ 1000 }
									placeholder="Search"
									/>
									<BootstrapTable
									{ ...props.baseProps }
									bordered={ false }
									striped
									hover
									condensed
									pagination={ paginationFactory(options) }
									/>
								</div>
								)
							}
						</ToolkitProvider>
					</RctCardContent>
				</RctCard >
			</div>
			);
		}
	}
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind, locale} = settings;
	return { isColorBlind, locale };
};



export default withRouter(connect(mapStateToProps)(inductStatus));
