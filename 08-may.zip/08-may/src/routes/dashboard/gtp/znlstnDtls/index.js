/**
 * Data Table
 */
import React from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';
import {graphQlURLPrd} from 'GraphQlUrl/Config';

import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass, { NumberFormatter } from 'Util/NumberClass';

//Reloadable card
import { WatchesWidget } from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable  from 'react-bootstrap-table-next';

import ReactToPrint from "react-to-print";

import ToolkitProvider, { Search }  from 'react-bootstrap-table2-toolkit';

//font-awesome icon
import "font-awesome/css/font-awesome.css";

import Spinner from 'Util/Spinner';
import PropTypes from 'prop-types';

import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import NoSsr from '@material-ui/core/NoSsr';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';

//import InputRange from 'react-input-range';
//For Drop Down menu

import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';

import InfiniteScroll from 'react-infinite-scroller';

const { SearchBar, ClearSearchButton } = Search;

import filterFactory, { textFilter, selectFilter  } from 'react-bootstrap-table2-filter';

import { DropdownToggle, DropdownMenu, Dropdown } from 'reactstrap';

import Tooltip from '@material-ui/core/Tooltip';

//JSON configurations
import json from 'JsnCnfg/WrkMntrng/GTPDshbrd/stnDtls/stnDtls.json';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

class ZonalNStationDtls extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = {
			value: this.props.match.params.operationStatus,
			zone: "zone",
			isLoading:true,
			data:[],
			enableSearch: false,
			enableFilter: false,
			fontDdOpen: false,
			fontValue: 0,
			fontClass: "font1"
		};

	}
	
	handleChange = (event, value) => {
		if (typeof value != "string"){
			return;
		}
		this.setState({ value });
		this.getGTPStationDetails(value, this.state.zone);
	};			

	handleChangeDropDown = (event, value) => {
		this.setState({ zone: value.props.value });
		this.getGTPStationDetails(this.state.value, value.props.value);
	};

	componentDidMount() {
		this.onReload();
	}
	
	onReload = () => {
		this.getGTPStationDetails(this.state.value, this.state.zone); 
	}
	
	//On click of font Button
	handleFontChange = (event) => {
		
		{/* To get the font class according to the font value selected */}
		let fontClass = event.target.value == 0 ? "font1" : (event.target.value == 5 ? "font2" : 
				(event.target.value == 10 ? "font3" : (event.target.value == 15 ? "font4" : (
				event.target.value == 20 ? "font5" : ""))));
				
		this.setState({fontValue: event.target.value, fontClass: fontClass});
	}
			
	getGTPStationDetails = (operation, zone) => {
		let startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
		let zoneId = zone === "zone" ? "" : zone;
		let functionVar = operation;
	
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!, $zoneId: String!, $functionVar: String!) { getGTPStationDetails( startTime: $startTime, xMins: 60, zoneId: $zoneId, function: $functionVar ) { stationId status stationRunTime operatorName operatorRunTime dwellTime itemsCompleted throughput productivity }}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId, functionVar} })
		}).then(r => r.json())
		.then(data => { 
				this.setState(
					{ 
						getGTPStationDetails: data.data.getGTPStationDetails, 
						isLoading:false
					}
				);
		})
		.catch((error) => {
			console.log(error);
			this.setState({ getGTPStationDetails: [],
						    isLoading:false
						  }); 
		});
	}
	
		
						
		render() {		
			const { classes } = this.props;
			const { value } = this.state;

			let stnDtlsConfig = json.container.leftSegment.components;
			//Check config from json for enabling CSV Export, Print, Column Search, Column filter, Read table columns
			const { 
				enableExportCSV, 
				enablePrint, 
				enableColSearch, 
				enableColFilter,
				enableFontSizeButton, 
				tableColumns, 
				operationTypes } = stnDtlsConfig[0].options;
			
			//Read table Operation Types from json config
			const labels = operationTypes;
			
			const selectOptions = {
				0: 'good',
				1: 'Bad',
				2: 'unknown'
			};

			var dynamicColumns = [];
			for(var i=0; i<tableColumns.length; i++)  {
				dynamicColumns.push(
						{
							dataField: tableColumns[i].dataField,
							text: <IntlMessages id={`GTP.stationDetails.${tableColumns[i].name}`} />,
							sort: tableColumns[i].sortable,
							filter: this.state.enableSearch == false ? (this.state.enableFilter == false ? "" 
							: selectFilter({
								options: selectOptions,
								placeholder: "select"
							}))
							: textFilter({
								placeholder: "Search..."
							})
						}
					);
			}
		
		{/* For Export Button */}
		const MyExportCSV = (props) => {
			const handleClick = () => {
				props.onExport();
			};
			return (
				<div>
					<button onClick={ handleClick }>
						<span className="material-icons">file_download</span>
					</button>
				</div>
			);
		};

		{/* For Search Button */}
		const SearchButton = () => {
			return (						
			  <div>
				<button onClick={() => {this.setState({enableSearch: !this.state.enableSearch, enableFilter: false });}}>
					<span className="material-icons">search</span>
				</button>
			  </div>
			);
		};
		  
		{/* For Reload Button */}
		const ReloadButton = () => {
			return (						
			  <div>
				<button onClick={() => {this.setState({isLoading: true, enableSearch: false, enableFilter: false}); this.onReload()}}>
					<span className="material-icons">refresh</span>
				</button>
			  </div>
			);
		};
		  
		{/* For Font Button */}
		const FontSizeButton = () => {		
			return (						
			  <div>
				<div><button onClick={() => {this.setState({isLoading: true, enableSearch: false, enableFilter: false}); this.onReload()}}>
					<span className="material-icons">format_size</span>
				</button></div>
					<div className="customInputRange">						
						  <input 
						  id="typeinp" 
						  type="range" 
						  min="0" max="15" 
						  value={this.state.fontValue} 
						  onChange={this.handleFontChange}
						  step="5"/>
					</div>
			  </div>
			);
		};
		
		{/* For Filter Button */}
		const FilterButton = () => {
			return (	
			  <div>
					<button onClick={() => {this.setState({ enableSearch: false, enableFilter: !this.state.enableFilter });}}>
						<span className="material-icons">filter_list</span>
					</button>
			  </div>
			);
		};
		  
		{/* close button to close search and filter panel */}
		const closePanel = () => {			
				this.setState({ enableSearch: false, enableFilter: false });			
		}

		{/* To Check search/filter buttomn is clicked or respective panel is opened*/}
		const chkPanel = (this.state.enableSearch == true || this.state.enableFilter == true)
		
		{/* to customize column header */}
		function customHeaderCheck(column, colIndex, { sortElement, filterElement }) {
			
		  return (
			
			<div className="customCheckMain">
			
			  <div className="customCheck">  { column.text }</div>
			  { sortElement } 
			  { filterElement } 
			  { (colIndex == columns.length -1 && chkPanel == true ) ? (
										<span className="customClose">
											<span className="displayButton" onClick={() => { 
											closePanel();}}>
												{/* <i class="fa fa-window-close-o" aria-hidden="true"></i> */}
												X
											</span>
										</span>
									  ) : (
										<div></div>
									  )}
		  
			</div>
		  );
		}
		
		{/* font class to be added into main div class */}
		const fontClass = this.state.fontClass;
			if(this.state.isLoading){
		    return (  
					<NoSsr>
					<div className={"customTab"}>	
							<Spinner />
					</div>
					</NoSsr>  
				);
		} else {
			return(
				<NoSsr>
					<div className={"customTab"+ fontClass}>		
						{<TabContainer>
							<ToolkitProvider
								keyField="id"
								data={ this.state.getGTPStationDetails } 
								columns={ dynamicColumns }    
								search
								exportCSV								
							>
							  {
								props => (	
									<div>
										<div>
											<div className= "headerLeft">
												<div className="breadcrum">Home / GTP Dashboard / Station Details</div>
												<div className="gtppage-title"><IntlMessages id={'GTP.stationDetails.title'} /></div>
											</div>
										</div>								
										<div className="barAndTable">	
											<AppBar position="static" className="customAppBar" style={{fontColor: '#647C72', backgroundColor: '#647C72'}}>
												<div className="tabAndDd">
													<div className="customTabLabels">
														<Tabs value={value} onChange={this.handleChange} className="customAppBar" >
														{labels && labels.map((label, key) => (
															<Tab style={{textTransform: 'uppercase'}} value={label} label={<IntlMessages id={`GTP.operation.${label}`} />} />
														))}
														</Tabs>
													</div>
													<div className="headerRight">

														{enableColSearch && (<div><SearchButton { ...props.searchProps } /></div>)}
														<div><ReloadButton { ...props.searchProps } /></div>										
														{enableColFilter && (<div><FilterButton { ...props.searchProps } /></div>)}
														{enableExportCSV && (<MyExportCSV { ...props.csvProps }></MyExportCSV>)}
														<div>
															<ReactToPrint
																trigger={() => <a href="#"><span className="material-icons">local_printshop</span></a>}
																content={() => this.table}
															/>
														</div>
														{enableFontSizeButton && (<div><FontSizeButton { ...props.searchProps } /></div>)}
														
													</div>																										
													<div className="customDd text-right">
														<FormControl>
															<Select
																value={this.state.zone}
																onChange={this.handleChangeDropDown}
																name="zone"
																IconComponent={props => (
																	<i {...props} className={`material-icons ${props.className}`}>
																		keyboard_arrow_down
																	</i>
																)}
															>
																<MenuItem value="zone"><IntlMessages id={'GTP.operation.ALL ZONES'} /></MenuItem>
																<MenuItem value={"Zone A"}>ZONE A</MenuItem>
																<MenuItem value={"Zone B"}>ZONE B</MenuItem>
																<MenuItem value={"Zone C"}>ZONE C</MenuItem>
															</Select>
													</FormControl>
												</div>
											</div>
										</AppBar>
										<InfiniteScroll
											pageStart={0}
											hasMore={true}
											loader={<div className="loader" key={0}></div>}
										>
											<div className="tableFont">	
												{<BootstrapTable
													{ ...props.baseProps }
													bordered={ false }
													filter={ filterFactory()}
												/>} 
											</div>
										</InfiniteScroll>
									</div> 
								</div>								  
								)
							  }
						</ToolkitProvider>					
					  </TabContainer>}
					  
					</div>
				  </NoSsr> 					
				);
			}
		}
}

export default ZonalNStationDtls;

