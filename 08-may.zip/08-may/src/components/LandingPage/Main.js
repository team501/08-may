import React, { Component } from 'react';
import {BrowserRouter, Route, Redirect, Switch, Link} from 'react-router-dom';
//import './landing.css';
import IntlMessages from 'Util/IntlMessages';
import Dashboard from '../../assets/img/dashboard.jpg';
import Manage from '../../assets/img/manage.jpg';
import Labour from '../../assets/img/labour.jpg';
import ManageEqe from '../../assets/img/manage_eqe.jpg';
import Workmonotring from '../../assets/img/work-monotring.jpg';
import ManageInvontry from '../../assets/img/manage-invontry.jpg';
import Exception from '../../assets/img/exceptions.jpg';
import Report from '../../assets/img/report.jpg';
import Footer from './Footer';
import  Access  from '../../constants/AccessConfig';
import { Alert } from 'react-bootstrap';

class Main extends React.Component {

	constructor(props) {
		super(props);
		this.state = { assignedPermissions: JSON.parse(localStorage.getItem("assignedPermissions")),
					   statusMessage: localStorage.getItem("statusMessage")
		};
	}

	componentDidMount() {
		this.setState({ assignedPermissions: JSON.parse(localStorage.getItem("assignedPermissions")),
					    statusMessage: localStorage.getItem("statusMessage")
		});
		console.log(this.state.assignedPermissions);
	}
	render(){
		return(
				<div className="main-bg">
				<div className="main-content">
				{ ( this.state.statusMessage.indexOf("LOGIN.FAILURE.CONTEXT") !== -1 ||
				    this.state.assignedPermissions.length === 0 ||
				    ( this.state.assignedPermissions.indexOf(Access.Dashboard) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.ManageOrder) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.BalanceLabour) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.ManageEquipment) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.WorkMonitoring) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.ManageInventory) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.Exceptions) === -1 &&
						      this.state.assignedPermissions.indexOf(Access.Report) === -1) 
				) && 
				
				(
						  <Alert bsStyle="default" className="loginAlert">
						  	<b> User does not have right Roles / Permissions. </b>
						  </Alert>
				)}
				
				{ this.state.assignedPermissions.length > 0 && 
					(
						<ul>
						{ this.state.assignedPermissions.indexOf(Access.Dashboard) > -1 && (
								<li>
									<div className="main-content-img"><img src={Dashboard}/></div>
									<div className="main-content-text"><IntlMessages id="LandingPage.dashboard" /></div>
								</li>
							) }
							

				{ this.state.assignedPermissions.indexOf(Access.ManageOrder) > -1 && (
						<li>
							<div className="main-content-img"><img src={Manage}/></div>
							<div className="main-content-text"><IntlMessages id="LandingPage.ManageOrderWaves" /></div>
						</li>
				) }

				{ this.state.assignedPermissions.indexOf(Access.BalanceLabour) > -1 && (
						<li>
							<div className="main-content-img"><img src={Labour}/></div>
							<div className="main-content-text"><IntlMessages id="LandingPage.BalanceLabour" /></div>
						</li>
				) }

				{ this.state.assignedPermissions.indexOf(Access.ManageEquipment) > -1 && (
						<li>
							<div className="main-content-img"><Link to={`/app/dashboard/manageEquipment`} activeClassName="active"><img src={ManageEqe}/></Link></div>
							<div className="main-content-text"><Link to={`/app/dashboard/manageEquipment`} activeClassName="active"><IntlMessages id="LandingPage.ManageEquipment" /></Link></div>
						</li>
				) }
				
				<div className="clear-both"></div>
				
				{ this.state.assignedPermissions.indexOf(Access.WorkMonitoring) > -1 && (
						<li>
							<div className="main-content-img"><img src={Workmonotring}/></div>
							<div className="main-content-text"><IntlMessages id="LandingPage.WorkMonitoring" /></div>
						</li>
				) }
				
				{ this.state.assignedPermissions.indexOf(Access.ManageInventory) > -1 && (
						<li>
							<div className="main-content-img"><img src={ManageInvontry}/></div>
							<div className="main-content-text"><IntlMessages id="LandingPage.ManageInventory" /></div>
						</li>
				) }


				{ this.state.assignedPermissions.indexOf(Access.Exceptions) > -1 && (
						<li>
							<div className="main-content-img"><img src={Exception}/></div>
							<div className="main-content-text"><IntlMessages id="LandingPage.Exceptions" /></div>
						</li>
				) }

							{ this.state.assignedPermissions.indexOf(Access.Report) > -1 && (
									<li>
										<div className="main-content-img"><img src={Report}/></div>
										<div className="main-content-text"><IntlMessages id="LandingPage.Report" /></div>
									</li>
							) }
							<li>
										<div className="main-content-img"><img src={Report}/></div>
										<div className="main-content-text"><Link to={`/app/dashboard/gtp`} activeClassName="active">GTP</Link></div>
									</li>
						</ul>
					)
				}
				</div>
				</div>
		);
	}
}
export default Main;
