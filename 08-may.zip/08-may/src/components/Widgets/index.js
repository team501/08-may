/**
 * App Widgets
 */
import React from 'react';
import Loadable from 'react-loadable';
import PreloadWidget from 'Components/PreloadLayout/PreloadWidget';

const MyLoadingComponent = () => (
   <PreloadWidget />
)


const TopNews = Loadable({
   loader: () => import("./TopNews"),
   loading: MyLoadingComponent
})

const TwitterFeedsV2 = Loadable({
   loader: () => import("./TwitterFeedsV2"),
   loading: MyLoadingComponent
})
const InductsForTheDayWidget = Loadable({
   loader: () => import("./InductsForTheDay"),
   loading: MyLoadingComponent
})
const WaveStatusWidget = Loadable({
   loader: () => import("./WaveStatus"),
   loading: MyLoadingComponent
})

const InductsForTheLastHourWidget = Loadable({
   loader: () => import("./InductsForTheLastHour"),
   loading: MyLoadingComponent
}) 

const SortsForTheDayWidget = Loadable({
   loader: () => import("./SortsForTheDay"),
   loading: MyLoadingComponent
}) 

const SortsForTheLastHourWidget = Loadable({
   loader: () => import("./SortsForTheLastHour"),
   loading: MyLoadingComponent
}) 

const SortersWidget = Loadable({
   loader: () => import("./Sorters"),
   loading: MyLoadingComponent
})

const InductionStatusWidget = Loadable({
   loader: () => import("./InductionStatus"),
   loading: MyLoadingComponent
})

const RuntimeWidget = Loadable({
   loader: () => import("./watches/Runtime"),
   loading: MyLoadingComponent
})

const StopsWidget = Loadable({
   loader: () => import("./watches/Stops"),
   loading: MyLoadingComponent
})

const TotalWidget = Loadable({
   loader: () => import("./watches/Total"),
   loading: MyLoadingComponent
})
const GtpWidget = Loadable({
   loader: () => import("./Gtp/index"),
   loading: MyLoadingComponent
})
const OperationWidget = Loadable({
   loader: () => import("./Gtp/operation/Operation"),
   loading: MyLoadingComponent
})
const BinRetrivalTimeWidget = Loadable({
   loader: () => import("./Gtp/binRetrivalTime/BinRetrivalTime"),
   loading: MyLoadingComponent
})
export {
   
   TwitterFeedsV2,
   InductsForTheDayWidget,
   WaveStatusWidget,
   InductsForTheLastHourWidget,
   SortsForTheDayWidget,
   SortsForTheLastHourWidget,
   SortersWidget,
   InductionStatusWidget,
   RuntimeWidget,
   StopsWidget,
   TotalWidget,
   GtpWidget,
   OperationWidget,
   BinRetrivalTimeWidget
}