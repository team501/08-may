import React, { Component } from 'react';

import {Link} from 'react-router-dom';

import Pbar from './Pbar.js';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import 'react-circular-progressbar/dist/styles.css';

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
// Import custom examples
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component

//json configurations
import json from 'JsnCnfg/WrkMntrng/GTPDshbrd/oprtns.json';

import {PickingWidget} from "Components/Widgets";
import Picking from "./Picking";
import Consolidation from "./Consolidation";
import Decanting from "./Decanting";
import CycleCount from "./CycleCount";

class OverallWorkMonitor extends Component {

	constructor(props) {
		super(props);
		this.state = {
		        ordersStatus: null,
		        zone: "zone"
		    }
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getCurrentValue();

	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getCurrentValue();
			
		}
	}
	
	getCurrentValue() {
		
	}
    
    componentDidMount() {
        this.getOrdersStatus();
    }
    
    // get orders status
    getOrdersStatus() {
        this.setState(
            { ordersStatus: [
                    {
                        "id": 1,
                        "label": "Picking",
                        "meassure":{
                            "progress":"In Units",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 25,
                            "units": "9999"
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 2,
                        "label": "Consolidation",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 10,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 3,
                        "label": "Decanting",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 18,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    },
                    {
                        "id": 4,
                        "label": "Cycle Count",
                        "meassure":{
                            "progress":"In Tasks",
                            "time":"hh:mm:ss"
                        },
                        "total": {
                            "units": 26000,
                            "time": "99:99:99"
                        },
                        "productivity": {
                            "percent": 20,
                            "units": 9999
                        },
                        "binRate": {
                            "process": 9999,
                            "processRate": 999
                        },
                        "others": {
                            "activeStations": 999,
                            "dwellTime":"00:00:00"
                        }
                    }
                ] 
            }
        );
    }
    
    handleChange = (event, value) => {
		this.setState({ zone: value.props.value  });
	};	
	
    render(){
		const { ordersStatus } = this.state;
		const { isColorBlind } = this.props;
		
		let bluecolorop = "#0685E3";
		let redcolor ="#D0021B";
		let greencolorp ="#03B819";
		if(isColorBlind){	
			bluecolorop = "#12A8F5";
			greencolorp ="#828275";
			redcolor ="#87871F";
		}

      return(
	  <RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"> 
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      	<div className="operation_bg overall-work-monitor">
							<div class="row row-no-margin">
								<div className="col-sm-10 col-md-10 col-lg-10 col-xl-10 title"><IntlMessages id={'GTP.operation.title'} /></div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 text-right">
									<FormControl fullWidth>
										<Select
										value={this.state.zone}
										onChange={this.handleChange}
										name="zone"
										IconComponent={props => (
											<i {...props} className={`material-icons ${props.className}`}>
												keyboard_arrow_down
											</i>
										)}
										>
										{/* <MenuItem value="all"><IntlMessages id={'GTP.operation.ALL ZONES'} /></MenuItem>
										<MenuItem value={10}><IntlMessages id={'GTP.operation.ZONE A'} /></MenuItem>
										<MenuItem value={20}><IntlMessages id={'GTP.operation.ZONE B'} /></MenuItem>
										<MenuItem value={30}><IntlMessages id={'GTP.operation.ZONE C'} /></MenuItem> */}

                                        <MenuItem value={"zone"}><IntlMessages id={'GTP.operation.ALL ZONES'} /></MenuItem>
										<MenuItem value={"Zone A"}>ZONE A</MenuItem>
										<MenuItem value={"Zone B"}>ZONE B</MenuItem>
										<MenuItem value={"Zone C"}>ZONE C</MenuItem>
										</Select>
									</FormControl>
								</div>
							</div>
							<div class="row row-no-margin text-center p-10">
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
								<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5"></div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 opHeadertext"> <IntlMessages id={'GTP.operation.Total'} /> </div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 opHeadertext"> <IntlMessages id={'GTP.operation.Productivity'} /> </div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 text-nowrap opHeadertext binstatus-text"> <IntlMessages id={'GTP.operation.Bin Status'} /> </div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 opHeadertext other-text"> <IntlMessages id={'GTP.operation.Others'} /> </div>
							</div>
								<Picking 
									currentTime={this.props.currentTime} 
									goal={999} 
									zone={this.state.zone === "zone" ? "" : this.state.zone}
								/>
								<Consolidation currentTime={this.props.currentTime} goal={999} zone={this.state.zone === "zone" ? "" : this.state.zone}/>
								<Decanting currentTime={this.props.currentTime} goal={999} zone={this.state.zone === "zone" ? "" : this.state.zone}/>
								<CycleCount currentTime={this.props.currentTime} goal={999} zone={this.state.zone === "zone" ? "" : this.state.zone}/>
							<div className="clearboth"></div>
							<Paper key={"completed"} elevation={2} square={true} component={'div'} className="mb-10 m-10 size-10 blue" style={{backgroundColor: bluecolorop}}></Paper>
							<span className="paperLabel"><IntlMessages id={'GTP.operation.Completed'} /></span>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<Paper key={"lagging"} elevation={2} square={true} className="size-10 ored" style={{backgroundColor: redcolor}}></Paper>
							<Paper key={"leading"} elevation={2} square={true} className="mb-10 m-10 size-10 oppgreen" style={{backgroundColor: greencolorp}}></Paper>
							<span className="paperLabel"><IntlMessages id={'GTP.operation.Time lapse'} /></span>
                     	</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			
                </RctCollapsibleCard>      
      );
    }
  }
  const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	//console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(OverallWorkMonitor));
//export default OverallWorkMonitor;
