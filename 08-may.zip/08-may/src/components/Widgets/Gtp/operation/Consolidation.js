import React, { Component } from 'react';

import {Link} from 'react-router-dom';

import Pbar from './Pbar.js';
//React collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import 'react-circular-progressbar/dist/styles.css';

//Intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
//Import Custom Widgets
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component

//JSON configurations
import json from 'JsnCnfg/WrkMntrng/GTPDshbrd/oprtns.json';
import {graphQlURLPrd} from 'GraphQlUrl/Config';

class Consolidation extends Component {
	
	constructor(props) {
		super(props);
		this.startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
		this.goalVal = this.props.goal;
		this.state = {
		        zone: "all",
		        binStatusProcessed:0,
				binStatusLastHour: 0,
				stationStatusActive: 0,
				dwellTime:"00:00",
				isUp: false,
				productivityPercentage: 0,
				productivityGoal: 0,
				
		    }
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getBinsProcessed();
		this.getBinsProcessedLastHour();
		this.getActiveStationStatus();
		this.getDwellTime();
		this.getProductivity();
		this.getItemsCompleted();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime || this.props.zone !== prevProps.zone) {
			this.startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getBinsProcessed();
			this.getBinsProcessedLastHour();
			this.getActiveStationStatus();
			this.getDwellTime();
			this.getProductivity();
			this.getItemsCompleted();
		}
	}
	
	getItemsCompleted() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let zoneId = this.props.zone;
		
		/*Productivity*/
		let query = 'query GetItemsCompleted($startTime: Long!, $zoneId: String!) {getItemsCompleted( startTime: $startTime, xMins: 60, zoneId: $zoneId, function: "Consolidation" )}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId } })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								itemsCompleted: data.data.getItemsCompleted,
								productivityGoal: this.goalVal,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ itemsCompleted: 0,
							productivityGoal: 0,
						    isLoading:false
						  }); 
		});
	}
	getProductivity() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let zoneId = this.props.zone;
		
		/*Productivity*/
		let query = 'query GetProductivity($startTime: Long!, $goalVal: Int, $zoneId: String!) {getProductivity( startTime: $startTime, xMins: 1446, zoneId: $zoneId, function: "Consolidation", goal: $goalVal )}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, goalVal, zoneId } })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								productivityPercentage: data.data.getProductivity,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ productivityPercentage: 0,
						    isLoading:false
						  }); 
		});
	}
	getDwellTime() {
		let startTime = this.startTime;
		let zoneId = this.props.zone;
		
		/*Active Stations*/
		let query = 'query GetDwellTime($startTime: Long!, $zoneId: String) {getDwellTime( startTime: $startTime, xMins: 60, zoneId: $zoneId, function: "Consolidation") { dwellTime isUp }}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								dwellTime: data.data.getDwellTime.dwellTime,
								isUp: data.data.getDwellTime.isUp,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ dwellTime: "00:00",
							isUp: false,
						    isLoading:false
						  }); 
		});
	}
	
	getActiveStationStatus() {
		let startTime = this.startTime;
		let zoneId = this.props.zone;
		
		/*Active Stations*/
		let query = 'query GetNumberOfActiveGTPStations($startTime: Long!, $zoneId: String!) {getNumberOfActiveGTPStations( startTime: $startTime, zoneId: $zoneId, function: "Consolidation")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								stationStatusActive: data.data.getNumberOfActiveGTPStations,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ stationStatusActive: 0,
						    isLoading:false
						  }); 
		});
	}
	getBinsProcessed() {
		let startTime = this.startTime;
		let zoneId = this.props.zone;
		
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!, $zoneId: String!) { getNumberOfBinsProcessed( startTime: $startTime, zoneId: $zoneId, function: "Consolidation")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								binStatusProcessed: data.data.getNumberOfBinsProcessed,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ binStatusProcessed: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getBinsProcessedLastHour() {
		let startTime = this.startTime;
		let zoneId = this.props.zone;
		
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!, $zoneId: String!) { getNumberOfBinsProcessed( startTime: $startTime, zoneId: $zoneId, xMins: 60, function: "Consolidation")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								binStatusLastHour: data.data.getNumberOfBinsProcessed,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ binStatusLastHour: 0,
						    isLoading:false
						  }); 
		});
	}
    
    
	 render(){
		const { isColorBlind } = this.props;
			
		let bluecolorop = "#0685E3";
		let redcolor ="#D0021B";
		let greencolorp ="#03B819";
		if(isColorBlind){	
			bluecolorop = "#12A8F5";
			greencolorp ="#828275";
			redcolor ="#87871F";
		}
		
		let operation = json.container.leftSegment
			 return( <Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/${operation.components[1].type}/znlstnDtls`}}>
								<div className="row row-no-margin opration-radius text-center">
									<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack d-flex align-items-center text-left"> 
										<IntlMessages id={`GTP.operation.${operation.components[1].type}`} />
									</div>
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
										<div className="row row-no-margin">
											<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-right">
												<div className="opcontainersubtext"><IntlMessages id={'GTP.operation.Progress'} /></div>
													<div className="opsmalltext"><i>(<IntlMessages id={`GTP.operation.${operation.components[1].components[0].units}`} />)</i></div>
												<div className="opcontainersubtext"><IntlMessages id={'GTP.operation.Time'} /></div>
												<div className="opsmalltext"><i>{`(hh:mm:ss)`}</i></div>
											</div>
											<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> 
											<Pbar percentage={80} 
                                            	  barColor={operation.components[1].components[3].options.color}/>
	                                        </div>
										</div>
									</div>
									<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
										<div className="station-status-textblack margin17"><NumberClass  number={26000} /></div>
										<div className="station-status-textblack margin28">99:99:99</div>
									</div>
									<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
										<div className="opAllG">
											<div className="ArcGauge" 
												style={{ width: '80px', height: '80px', margin: '0 auto', marginTop: '10%'}}>
	                                            <SegmentedArcProgressbar 
	                                                percentage={this.state.productivityPercentage}
	                                                segments={operation.components[1].components[3].options.segments} 
	                                                textColor={operation.components[1].components[3].options.textColor}
	                                                segmentColors={operation.components[1].components[3].options.segmentColors}
	                                                segmentPercentage={operation.components[1].components[3].options.segmentPercentage}
	                                                barWidth={operation.components[1].components[3].options.barWidth}
	                                            />
											</div>
											<div className="prodLabel"><b><NumberClass  number={this.state.itemsCompleted} /></b>/<NumberClass  number={this.state.productivityGoal} /></div>
											<div className="opsmalltext"><i>(<IntlMessages id={'GTP.operation.Last Hour'} />)</i></div>
										</div>
									</div>
									<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
										<div className="station-status-textblack margin17"><NumberClass  number={this.state.binStatusProcessed} /></div>
										<div className="opsmalltext station-status-activetext"><IntlMessages id={'GTP.operation.Processed'} /></div>
										<div className="station-status-textblack"><NumberClass  number={this.state.binStatusLastHour} /></div>
										<div className="opsmalltext text-nowrap"><IntlMessages id={'GTP.operation.Process Rate'} /></div>
	                                    <div className="opsmalltext station-status-activetext noWrap"><i>(<IntlMessages id={'GTP.operation.Last Hour'} />)</i></div>
									</div>
									<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignOthers">
										<div className="station-status-textblack margin17"><NumberClass  number={this.state.stationStatusActive} /></div>
										<div className="opsmalltext station-status-activetext noWrap"><IntlMessages id={'GTP.operation.Active Stations'} /></div>
										<div className="station-status-textblack opblack">{this.state.isUp && (<span style={{color: greencolorp}}>&#x2BC5;</span>)}{ !this.state.isUp && (<span style={{color: redcolor}}>&#x2BC6;</span>)}{this.state.dwellTime}</div>
										{/* <div className="opsmalltext"><i><IntlMessages id={'GTP.operation.Last Hour'} /></i></div> */}
										<div className="opsmalltext station-status-activetext noWrap"><IntlMessages id={'GTP.operation.Dwell Time'} /></div>
									</div>								
								</div>
								</Link>
							);
	 }
}

const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	//console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
}

export default withRouter(connect(mapStateToProps)(Consolidation));