/**
 * InductsForTheDay
 */
import React, { Component } from 'react';
import {Link} from 'react-router-dom'; 
//axios
import axios from 'axios';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/inductionStatusPerHourJson';
// intl messages
import IntlMessages from 'Util/IntlMessages';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';

//circular-progressbar
import CircularProgressbar from 'react-circular-progressbar';
import NumberClass, {NumberFormatter} from 'Util/NumberClass';
//bar chart
import {Bar} from 'react-chartjs-2';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import Spinner from 'Util/Spinner';

class InductionStatus extends Component {
	constructor(props) {
		super(props);
		this.state = { barData: [], value:[]
		};
	}
	
	/*
	* calling rest for the first time after mount
	* it will call render twice but update only once
	* Used to remove unsafe life cycle methods.
	*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	// recent orders
	getRecentOrders() {
		
		let query = json.container.leftSegment.components[0].options.query;
		
		let startTime = 201903221245;//dateFormat(new Date(), "yyyymmddHHMM");
		let sorterId = this.props.sorterId;
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, sorterId }
			})
		})
		.then(r => r.json())
		.then(data => { 

			let label = data.data.getUSSInductionStatus.statuses.map(data =>  " ");
			//let value=[2345,6453,4895]
		    let value = data.data.getUSSInductionStatus.statuses.map(data => data.inductsCount);
		    value = value != null && value.length > 0 ? [...value, Math.min(...value)-100] : [];
		    //console.log(label);
		    this.setState({ label: label,
				   			value: value,
						    isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ label: [],
				   			value: [],
				   			isLoading:false
						 }); 
		});
	}
	
	renderChartLabels (chartLabel, value) {
		
		console.log("value ...."+value);
		return (
			<div className="chartLabel">
				<IntlMessages id={`indvlSoterDashbrd.${chartLabel}`} /> 
				<span>&nbsp;(<NumberClass  number={parseInt(value)} />)</span>
			</div>
		);
	}
	render() {
		
		//Check For color blind and change the color
				const { isColorBlind } = this.props;				
				
				let backgroundColors = json.container.leftSegment.components[0].options.backgroundColors
				let borderColors = json.container.leftSegment.components[0].options.borderColors
				let hoverBackgroundColor = json.container.leftSegment.components[0].options.hoverBackgroundColor
				let hoverBorderColor = json.container.leftSegment.components[0].options.hoverBorderColor
				//let labelData = json.container.leftSegment.components[0].options.labels;
				
				 let labelData = ["Peak", "Average", "Recirc", "Minimum"];
				
				if(isColorBlind){			
					backgroundColors = [ "#828275", "#828275", "#f8e71c",  "#87871f" ]
					borderColors = [  "#828275", "#828275", "#f8e71c",  "#87871f" ]
					hoverBackgroundColor = [  "#828275", "#828275", "#f8e71c",  "#87871f" ]
					hoverBorderColor = [  "#828275", "#828275", "#f8e71c",  "#87871f" ]
				}
				
				// all Options from json
				let borderWidth = json.container.leftSegment.components[0].options.borderWidth;
				let width = json.container.leftSegment.components[0].options.width;
				let height = json.container.leftSegment.components[0].options.height;
				let displayLegend = json.container.leftSegment.components[0].options.displayLegend;
				
				let xAxisTicksPosition = json.container.leftSegment.components[0].options.xAxisTicksPosition;
				let barPercentage = json.container.leftSegment.components[0].options.barPercentage;
				let xAxisTicksFontSize = json.container.leftSegment.components[0].options.xAxisTicksFontSize;
				let xAxisTickFontWeight = json.container.leftSegment.components[0].options.xAxisTickFontWeight;
				let xAxisDisplayGridLines = json.container.leftSegment.components[0].options.xAxisDisplayGridLines;
				
				let yAxisTicksPosition = json.container.leftSegment.components[0].options.yAxisTicksPosition;
				let yAxisTicksFontSize = json.container.leftSegment.components[0].options.yAxisTicksFontSize;
				let yAxisTickFontWeight = json.container.leftSegment.components[0].options.yAxisTickFontWeight;
				let yAxisDisplayGridLines = json.container.leftSegment.components[0].options.yAxisDisplayGridLines;
				
				
		let data = { 
						labels: this.state.label,
						datasets: [{ 
							backgroundColor:backgroundColors,
							borderColor: borderColors,		  			
							borderWidth: borderWidth,
							hoverBackgroundColor:hoverBackgroundColor, //Optional
							hoverBorderColor: hoverBorderColor, //Optional
							data: this.state.value
						}]
				};
		console.log("Hi.."+ JSON.stringify(this.state.value))
	if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										fullBlock > 
							<Spinner />
					</RctCollapsibleCard>);
	} else {
		return (
			<div className="div-height">
				<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={<IntlMessages id="indvlSoterDashbrd.indusctStatusFrLstHr" />}
					fullBlock
				>
					<div className="col-md-10 col-xl-10 col-sm-10 col-ls-10 float-left induction-status-area-height">  
						<Bar data={data} width={width} height={height} 
							options={{ maintainAspectRatio: false, 
							legend: {
								display: displayLegend
							},
							tooltips: {
									callbacks: {
										label: function(tooltipItem, data) {
											let label = data.datasets[tooltipItem.datasetIndex].label || '';

											if (label) {
												label += ': ';
											}
											label += NumberFormatter(tooltipItem.yLabel);
											return label;
										}
									}
								},
							scales: {
								xAxes: [{
									position: xAxisTicksPosition,
									barPercentage: barPercentage,
									ticks: {
										display: false,
										fontSize: xAxisTicksFontSize,
										fontWeight: xAxisTickFontWeight
									},
									gridLines : {
						                display : xAxisDisplayGridLines
						            } 
								}],
								
								yAxes: [{
									position: yAxisTicksPosition,
									ticks: {
										fontSize: yAxisTicksFontSize,
										fontWeight: yAxisTickFontWeight,
										callback: function(value, index, values) {
											return NumberFormatter(value);
										}
									},
									gridLines : {
						                display : yAxisDisplayGridLines
						            }
								}]
							}  }}
						/> 
					</div>
					<div class="right-arrow_induct col-md-1 col-xl-1 col-sm-1 col-ls-1">
						<Link to={{ pathname: `/app/dashboard/${this.props.nextLink}/inductDetails`}}>
							&#x203A;
						</Link>
					</div>
					<div className="induction-status-area-height1">
							{labelData.map((chartLabel, i) => this.renderChartLabels(chartLabel, JSON.stringify(this.state.value[i])))}
					</div>

				</RctCollapsibleCard>
			</div>
		);
		}
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(InductionStatus));